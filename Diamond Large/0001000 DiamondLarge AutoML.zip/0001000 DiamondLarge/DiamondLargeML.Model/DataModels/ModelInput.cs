//*****************************************************************************************
//*                                                                                       *
//* This is an auto-generated file by Microsoft ML.NET CLI (Command-Line Interface) tool. *
//*                                                                                       *
//*****************************************************************************************

using Microsoft.ML.Data;

namespace DiamondLargeML.Model.DataModels
{
    public class ModelInput
    {
        [ColumnName("ID"), LoadColumn(0)]
        public float ID { get; set; }


        [ColumnName("carat"), LoadColumn(1)]
        public float Carat { get; set; }


        [ColumnName("cut"), LoadColumn(2)]
        public string Cut { get; set; }


        [ColumnName("color"), LoadColumn(3)]
        public string Color { get; set; }


        [ColumnName("clarity"), LoadColumn(4)]
        public string Clarity { get; set; }


        [ColumnName("depth"), LoadColumn(5)]
        public float Depth { get; set; }


        [ColumnName("table"), LoadColumn(6)]
        public float Table { get; set; }


        [ColumnName("price"), LoadColumn(7)]
        public float Price { get; set; }


        [ColumnName("x"), LoadColumn(8)]
        public float X { get; set; }


        [ColumnName("y"), LoadColumn(9)]
        public float Y { get; set; }


        [ColumnName("z"), LoadColumn(10)]
        public float Z { get; set; }


    }
}
