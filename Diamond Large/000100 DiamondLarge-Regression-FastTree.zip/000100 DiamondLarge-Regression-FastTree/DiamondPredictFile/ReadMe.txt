﻿Batch Predict from file

Test file from = @"E:\ml\diamonds-Large-Test.csv";

Model from @"E:\ml\diamondsModel.zip";

