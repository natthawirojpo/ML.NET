﻿//  * LOY 2019 ML.NET Course
// Predict batch from file

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.ML;
using Microsoft.ML.Data;
using static Microsoft.ML.DataOperationsCatalog;
using Microsoft.ML.Trainers;
using Microsoft.ML.Transforms.Text;
using System.Text;

namespace DiamondPredictFile
{
    class Program
    {
        static void Main(string[] args)
        {
            // Set data set path
            string testDataPath = @"E:\ml\diamonds-Large-Test.csv";
            string modelPath = @"E:\ml\diamondsModel.zip";


            // Create context
            MLContext mlContext = new MLContext(seed: 0);

            // Read test file
            string[] lines = System.IO.File.ReadAllLines(testDataPath);

            // Create DiamondSheme object array
            // - 2 because first line is header
            DiamondSheme[] myTest = new DiamondSheme[lines.Count()-2];

            // Assign value to each object in array
            for (int i = 1; i < lines.Count()-1; i++)
            {
                string[] myArray = lines[i].ToString().Split(',');

                // Make one test diamond data we want to predict
                int j = 0;
                var myDiamond = new DiamondSheme()
                {
                    Id = myArray[j++],
                    Carat = float.Parse(myArray[j++]),
                    Cut = myArray[j++],
                    Color = myArray[j++],
                    Clearity = myArray[j++],
                    Depth = float.Parse(myArray[j++]),
                    Table = float.Parse(myArray[j++]),
                    Price = float.Parse(myArray[j++]),
                    LengthX = float.Parse(myArray[j++]),
                    WidthY = float.Parse(myArray[j++]),
                    DepthZ = float.Parse(myArray[j++]),
                };
                myTest[i-1] = myDiamond;
            }

            // Load from enumberable
            IDataView batchView = mlContext.Data.LoadFromEnumerable(myTest);

            // Load Model
            ITransformer loadedModel = mlContext.Model.Load(modelPath, out var modelInputSchema);

            // Create prediction view
            IDataView predictions = loadedModel.Transform(batchView);

            // Create enumerable prediction
            IEnumerable<DiamondPredict> predictedResults = mlContext.Data.CreateEnumerable<DiamondPredict>
                (predictions, reuseRowObject: false);

            // Display Results
            Console.WriteLine("==== Prediction with multiple rows from file ===");
            Console.WriteLine("--------------------------------------------------");
            foreach (DiamondPredict prediction in predictedResults)
            {
                Console.WriteLine($"Actual price: {prediction.Price} \t| Predicted price: {prediction.ScorePrice:0.##}");
            }
            Console.WriteLine("=============== End of predictions ===============");
        }
    }
}

/*
 Output result

==== Prediction with multiple rows from file ===
--------------------------------------------------
Actual price: 658       | Predicted price: 690.46
Actual price: 4590      | Predicted price: 5218.84
Actual price: 10019     | Predicted price: 9264.9
Actual price: 2645      | Predicted price: 2284.89
Actual price: 612       | Predicted price: 731.18
Actual price: 10934     | Predicted price: 12407.9
Actual price: 15067     | Predicted price: 15014.8
Actual price: 5337      | Predicted price: 5351.65
Actual price: 680       | Predicted price: 687.55
Actual price: 4435      | Predicted price: 3898.39
Actual price: 558       | Predicted price: 602.48
Actual price: 1186      | Predicted price: 1208.73
Actual price: 7418      | Predicted price: 7408.04
Actual price: 14359     | Predicted price: 14368.6
Actual price: 5408      | Predicted price: 5248.16
Actual price: 13506     | Predicted price: 13644.2
=============== End of predictions ===============

 */
