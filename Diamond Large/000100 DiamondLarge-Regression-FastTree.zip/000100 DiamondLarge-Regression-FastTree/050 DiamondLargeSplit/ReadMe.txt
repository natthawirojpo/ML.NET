﻿//  * LOY 2019 ML.NET Course

Demonstrate how to split dataSet 
80% training
20% evaluate