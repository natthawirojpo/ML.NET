﻿//  * LOY 2019 ML.NET Course

Build, evaluate and save mode for later use. No prediction