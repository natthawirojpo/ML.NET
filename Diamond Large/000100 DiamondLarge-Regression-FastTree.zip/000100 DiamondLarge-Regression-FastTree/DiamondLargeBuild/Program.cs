﻿//  * LOY 2019 ML.NET Course
// Build test score and save model

using System;
using System.IO;
using System.Linq;
using Microsoft.ML;

namespace DiamondLargeBuild
{
    class Program
    {
        static void Main(string[] args)
        {
            // Set data set path
            string trainDataPath = @"E:\ml\diamonds-Large-Train.csv";
            string scoreDataPath = @"E:\ml\diamonds-Large-Score.csv";
            string modelPath = @"E:\ml\diamondsModel.zip";

            // Create context
            MLContext mlContext = new MLContext(seed: 0);

            // Load train data
            IDataView trainDataView = mlContext.Data.LoadFromTextFile<DiamondSheme>
                (trainDataPath, hasHeader: true, separatorChar: ',');

            // -------------------------------------------------------------------
            // Create pipeline
            var pipeline = mlContext.Transforms.CopyColumns
                (outputColumnName: "Label", inputColumnName: "Price")

                //  Transform the categorical data  values into numbers
                .Append(mlContext.Transforms.Categorical.OneHotEncoding
                    (outputColumnName: "CutNum", inputColumnName: "Cut"))

                .Append(mlContext.Transforms.Categorical.OneHotEncoding
                    (outputColumnName: "ColorNum", inputColumnName: "Color"))

                .Append(mlContext.Transforms.Categorical.OneHotEncoding
                    (outputColumnName: "ClearityNum", inputColumnName: "Clearity"))

                // combines all of the feature columns into the Features column
                .Append(mlContext.Transforms.Concatenate
                    ("Features", "Carat", "CutNum", "ColorNum", "ClearityNum", "Depth",
                    "Table", "LengthX", "WidthY", "DepthZ"))

                // Choose a learning algorithm
                .Append(mlContext.Regression.Trainers.FastTree());

            // ----------------------------------------------------------------------
            // Train the model
            Console.WriteLine($"Strat training. {DateTime.Now}");
            var myModel = pipeline.Fit(trainDataView);
            Console.WriteLine($"Training done. {DateTime.Now}");

            // Loads the test dataset.
            trainDataView = mlContext.Data.LoadFromTextFile<DiamondSheme>
                (scoreDataPath, hasHeader: true, separatorChar: ',');

            // Creates the regression evaluator.
            var predictions = myModel.Transform(trainDataView);

            // -------------------------------------------------------------------------
            // Evaluates the model and creates metrics.
            var metrics = mlContext.Regression.Evaluate(predictions, "Label", "Score");

            Console.WriteLine();
            Console.WriteLine($"*************************************************");
            Console.WriteLine($"* Model quality metrics evaluation ");
            Console.WriteLine($"*------------------------------------------------");

            // RSquared is another evaluation metric of the regression models.
            // RSquared takes values between 0 and 1.The closer its value is to 1, the better the model is
            Console.WriteLine($"* RSquared Score: {metrics.RSquared:0.##}");

            // RMS is one of the evaluation metrics of the regression model. 
            // The lower it is, the better the model is
            Console.WriteLine($"* Root Mean Squared Error: {metrics.RootMeanSquaredError:#.##}");

            // Save model
            mlContext.Model.Save(myModel, trainDataView.Schema, modelPath);
        }
    }
}
