﻿//  * LOY 2019 ML.NET Course
// Manage NuGet Packages
// Microsoft.ML
// Microsoft.ML.FastTree
// Create folder Data

using System;
using System.IO;
using Microsoft.ML;

namespace TaxiFarePrediction
{
    class Program
    {
        static readonly string _trainDataPath = Path.Combine
            (Environment.CurrentDirectory, "Data", "taxi-fare-train.csv");
        static readonly string _testDataPath = Path.Combine
            (Environment.CurrentDirectory, "Data", "taxi-fare-test.csv");

        static void Main(string[] args)
        {
            // create comtext
            MLContext mlContext = new MLContext(seed: 0);

            // train model
            var model = Train(mlContext, _trainDataPath);

            // Evaluate the model
            Evaluate(mlContext, model);

            // Use the model for predictions
            TestSinglePrediction(mlContext, model);


        }

        public static ITransformer Train(MLContext mlContext, string dataPath)
        {
            /*
             * The Train() method executes the following tasks:
                    Loads the data.
                    Extracts and transforms the data.
                    Trains the model.
                    Returns the model.
             */

            // Load train data
            Console.WriteLine("Load train data.");
            IDataView dataView = mlContext.Data.LoadFromTextFile<TaxiTrip>(dataPath, hasHeader: true, separatorChar: ',');

            // create pipeline
            // FareAmount column is the Label
            Console.WriteLine("create pipeline.");
            var pipeline = mlContext.Transforms.CopyColumns(outputColumnName: "Label", inputColumnName: "FareAmount")

                // The algorithm that trains the model requires numeric features
                // so you have to transform the categorical data ( VendorId , RateCode , and PaymentType ) 
                // values into numbers(VendorIdEncoded, RateCodeEncoded, and PaymentTypeEncoded).
                .Append(mlContext.Transforms.Categorical.OneHotEncoding
                    (outputColumnName: "VendorIdEncoded",inputColumnName: "VendorId"))

                .Append(mlContext.Transforms.Categorical.OneHotEncoding
                    (outputColumnName: "RateCodeEncoded", inputColumnName:"RateCode"))

                .Append(mlContext.Transforms.Categorical.OneHotEncoding
                    (outputColumnName: "PaymentTypeEncoded",inputColumnName: "PaymentType"))


                // combines all of the feature columns into the Features column
                .Append(mlContext.Transforms.Concatenate
                    ("Features", "VendorIdEncoded", "RateCodeEncoded", "PassengerCount", 
                        "TripTime", "TripDistance", "PaymentTypeEncoded"))

                // Choose a learning algorithm
                .Append(mlContext.Regression.Trainers.FastTree());

            // Train the model
            Console.WriteLine($"Strat training. {DateTime.Now}");
            var model = pipeline.Fit(dataView);
            Console.WriteLine($"Training done. {DateTime.Now}");

            return model;
        }

        private static void Evaluate(MLContext mlContext, ITransformer model)
        {
            /*
            The Evaluate method executes the following tasks:
                Loads the test dataset.
                Creates the regression evaluator.
                Evaluates the model and creates metrics.
                Displays the metrics.
            */

            // Loads the test dataset.
            Console.WriteLine("Loads the test dataset.");
            IDataView dataView = mlContext.Data.LoadFromTextFile<TaxiTrip>
                (_testDataPath, hasHeader: true, separatorChar:',');

            // Creates the regression evaluator.
            // The Transform() method makes predictions for the test dataset input rows.
            Console.WriteLine("Creates the regression evaluator.");
            var predictions = model.Transform(dataView);

            // Evaluates the model and creates metrics.
            // computes the quality metrics for the PredictionModel using the specified dataset.
            Console.WriteLine("Evaluates the model and creates metrics.");
            var metrics = mlContext.Regression.Evaluate(predictions, "Label", "Score");

            Console.WriteLine();
            Console.WriteLine($"*************************************************");
            Console.WriteLine($"* Model quality metrics evaluation ");
            Console.WriteLine($"*------------------------------------------------");

            // RSquared is another evaluation metric of the regression models.
            // RSquared takes values between 0 and 1.The closer its value is to 1, the better the model is
            Console.WriteLine($"* RSquared Score: {metrics.RSquared:0.##}");

            // RMS is one of the evaluation metrics of the regression model. 
            // The lower it is, the better the model is
            Console.WriteLine($"* Root Mean Squared Error: {metrics.RootMeanSquaredError:#.##}");
        }

        private static void TestSinglePrediction(MLContext mlContext, ITransformer model)
        {
            /*
             The TestSinglePrediction method executes the following tasks:
                    Creates a single comment of test data.
                    Predicts fare amount based on test data.
                    Combines test data and predictions for reporting.
                    Displays the predicted results. 
                    */

            // create engine
            var predictionFunction = mlContext.Model.CreatePredictionEngine<TaxiTrip, TaxiTripFarePrediction>(model);


            // make one test trip data we want to predict
            var taxiTripSample = new TaxiTrip()
            {
                VendorId = "VTS",
                RateCode = "1",
                PassengerCount = 1,
                TripTime = 1140,
                TripDistance = 3.75f,
                PaymentType = "CRD",
                FareAmount = 0 // To predict. Actual/Observed = 15.5
            };

            // make prediction
            var prediction = predictionFunction.Predict(taxiTripSample);

            Console.WriteLine($"**********************************************************************");
            Console.WriteLine($"Predicted fare: {prediction.FareAmount:0.####}, actual fare: 15.5");
            Console.WriteLine($"**********************************************************************");
        }
    }
}

/*
Load train data.
create pipeline.
Strat training. 6/16/2019 9:35:31 AM
Training done. 6/16/2019 9:35:39 AM
Loads the test dataset.
Creates the regression evaluator.
Evaluates the model and creates metrics.

*************************************************
* Model quality metrics evaluation
*------------------------------------------------
* RSquared Score: 0.92
* Root Mean Squared Error: 2.81
**********************************************************************
Predicted fare: 15.7855, actual fare: 15.5
**********************************************************************
 */
