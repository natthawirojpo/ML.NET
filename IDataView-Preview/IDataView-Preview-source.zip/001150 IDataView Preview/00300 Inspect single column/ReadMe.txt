﻿nspect values in a single column

At any point in the model building process, values in a single column 
of an IDataView can be accessed using the GetColumn method. 
The GetColumn method returns all of the values in a single column as an IEnumerable.