using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.ML;
using Microsoft.ML.Data;

namespace WebApplication4
{
    public class DiamondScheme
    {
        [LoadColumn(0)]
        public float Size { get; set; }
        [LoadColumn(1)]
        public float Price { get; set; }
    }
    public class DiamonPredic : DiamondScheme
    {
        [ColumnName("Score")]
        public float PricePredict { get; set; }
    }

    public class Startup
    {
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapGet("/", async context => { test(context);});
            });
        }
        public async void test(HttpContext context)
        {
            string trainDataPath = @"E:\ml\diamondSmall.csv";

            // create context
            MLContext mlContext = new MLContext();

            // Load train data
            IDataView trainData = mlContext.Data.LoadFromTextFile<DiamondScheme>
                (trainDataPath, hasHeader: true, separatorChar: ',');

            // debug watch
            var myPreview = trainData.Preview();

            // create pipe line
            var pipeline = mlContext.Transforms.Concatenate
                ("Features", new[] { "Size" })

            // set training algorithm
                .Append(mlContext.Regression.Trainers.Sdca
                    (labelColumnName: "Price",
                    maximumNumberOfIterations: 100));

            // Train model
            var myModel = pipeline.Fit(trainData);

            // Make a prediction
            var mySize = new DiamondScheme() { Size = 1.35F };
            var myPrice = mlContext.Model.CreatePredictionEngine
                <DiamondScheme, DiamonPredic>
                (myModel).Predict(mySize);

            // Show result
            await context.Response.WriteAsync("===========================\n");
            await context.Response.WriteAsync("Predicted result\n");
            await context.Response.WriteAsync("-----------------------------\n");
            await context.Response.WriteAsync($"Size = {mySize.Size} " +
                $": Price = {myPrice.PricePredict:C}\n");
            await context.Response.WriteAsync("-----------------------------");

        }
    }
}
