﻿//  * LOY 2019 ML.NET Course

using System;
using Microsoft.ML;
using Microsoft.ML.Data;

namespace HelloWorld
{
    public class DiamondScheme
    {
        [LoadColumn(0)]
        public float Size { get; set; }
        [LoadColumn(1)]
        public float Price { get; set; }
    }
    public class DiamonPredic: DiamondScheme
    {
        [ColumnName("Score")]
        public float PricePredict { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            string trainDataPath = @"E:\ml\diamondSmall.csv";

            // create context
            MLContext mlContext = new MLContext();

            // Load train data
            IDataView trainData = mlContext.Data.LoadFromTextFile<DiamondScheme>
                (trainDataPath, hasHeader: true, separatorChar: ',');

            // debug watch
            var myPreview = trainData.Preview();

            // create pipe line
            var pipeline = mlContext.Transforms.Concatenate
                ("Features", new[] { "Size" })

            // set training algorithm
                .Append(mlContext.Regression.Trainers.Sdca
                    (labelColumnName: "Price",
                    maximumNumberOfIterations: 100));

            // Train model
            var myModel = pipeline.Fit(trainData);

            // Make a prediction
            var mySize = new DiamondScheme() { Size = 1.35F };
            var myPrice = mlContext.Model.CreatePredictionEngine
                <DiamondScheme, DiamonPredic>
                (myModel).Predict(mySize);

            // Show result
            Console.WriteLine("\n===========================");
            Console.WriteLine("Predicted result");
            Console.WriteLine("-----------------------------");
            Console.WriteLine($"Size = {mySize.Size} " +
                $": Price = {myPrice.PricePredict:C}");
            Console.WriteLine("-----------------------------");
        }
    }
}
