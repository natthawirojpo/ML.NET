﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.ML;
using Microsoft.ML.Data;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string trainDataPath = @"E:\ml\diamondSmall.csv";

            // create context
            MLContext mlContext = new MLContext();

            // Load train data
            IDataView trainData = mlContext.Data.LoadFromTextFile<DiamondScheme>
                (trainDataPath, hasHeader: true, separatorChar: ',');

            // debug watch
            var myPreview = trainData.Preview();

            // create pipe line
            var pipeline = mlContext.Transforms.Concatenate
                ("Features", new[] { "Size" })

            // set training algorithm
                .Append(mlContext.Regression.Trainers.Sdca
                    (labelColumnName: "Price",
                    maximumNumberOfIterations: 100));

            // Train model
            var myModel = pipeline.Fit(trainData);

            // Make a prediction
            var mySize = new DiamondScheme() { Size = 1.35F };
            var myPrice = mlContext.Model.CreatePredictionEngine
                <DiamondScheme, DiamonPredic>
                (myModel).Predict(mySize);

            // Show result
            label1.Text = "===========================\n";
            label1.Text += "Predicted result\n";
            label1.Text += "-----------------------------\n";
            label1.Text += $"Size = {mySize.Size} " +
                $": Price = {myPrice.PricePredict:C}\n";
            label1.Text += "-----------------------------";
        }
    }

    public class DiamondScheme
    {
        [LoadColumn(0)]
        public float Size { get; set; }
        [LoadColumn(1)]
        public float Price { get; set; }
    }
    public class DiamonPredic : DiamondScheme
    {
        [ColumnName("Score")]
        public float PricePredict { get; set; }
    }
}
