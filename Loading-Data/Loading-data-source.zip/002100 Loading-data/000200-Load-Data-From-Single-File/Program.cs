﻿//  * LOY 2019 ML.NET Course

using System;
using Microsoft.ML;
using Microsoft.ML.Data;
using System.Collections.Generic;
using System.Linq;

namespace test
{
/*
Size (Sq. ft.), HistoricalPrice1 ($), HistoricalPrice2 ($), HistoricalPrice3 ($), Current Price ($)
700, 100000, 3000000, 250000, 500000
1000, 600000, 400000, 650000, 700000     
*/


    public class HousingData
    {
        // The LoadColumn attribute specifies your properties' column indices
        [LoadColumn(0)]
        public float Size { get; set; }

        // Multiple columns at a time in the form of a vector
        [LoadColumn(1, 3)]
        [VectorType(3)]
        public float[] HistoricalPrices { get; set; }


        [LoadColumn(4)]
        [ColumnName("Label")]
        public float CurrentPrice { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //Create MLContext
            MLContext mlContext = new MLContext();

            //Load Data
            IDataView data = mlContext.Data.LoadFromTextFile<HousingData>(
                @"E:\ml\house.csv",
                separatorChar: ',',
                hasHeader: true);

            // show column Size
            IEnumerable<float> sizeColumn = data.GetColumn<float>("Size").ToList();
            foreach (var v in sizeColumn)
                Console.Write(v + ",");

            // show column Label
            IEnumerable<float> labelColumn = data.GetColumn<float>("Label").ToList();
            foreach (var v in labelColumn)
                Console.Write(v + ",");

        }
    }
}
