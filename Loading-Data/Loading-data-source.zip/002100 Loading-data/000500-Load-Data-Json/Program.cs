﻿//  * LOY 2019 ML.NET Course

// add NuGet Json.NET Newtonsoft.Json by James Newton-King

using System;
using Microsoft.ML;
using Microsoft.ML.Data;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using System.IO;
using System.Data;

namespace test
{
    class Diamond
    {
        [LoadColumn(0)]
        public float Size { get; set; }
        [LoadColumn(1)]
        public float Price { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            string path = @"E:\ml\diamond.json";

            // Open the file to read from.
            string json = File.ReadAllText(path);

            // convert json to dataset
            DataSet dataSet = JsonConvert.DeserializeObject<DataSet>(json);

            // add dataset to a table
            DataTable dataTable = dataSet.Tables["Table1"];

            // convert dataTabe to list
            List<Diamond> myData = new List<Diamond>();
            foreach (DataRow row in dataTable.Rows)
            {
                Diamond a = new Diamond();
                a.Size = Convert.ToSingle(row["Size"]);
                a.Price = Convert.ToSingle(row["Price"]);
                myData.Add(a);
            }

            //Create MLContext
            MLContext mlContext = new MLContext();

            //Load Data
            IDataView data = mlContext.Data.LoadFromEnumerable<Diamond>(myData);

            // show column Size
            IEnumerable<float> sizeColumn = data.GetColumn<float>("Size").ToList();
            foreach (var v in sizeColumn)
                Console.WriteLine(v);
        }
    }
}
