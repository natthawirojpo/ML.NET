﻿//  * LOY 2019 ML.NET Course

using System;
using Microsoft.ML;
using Microsoft.ML.Data;
using System.Collections.Generic;
using System.Linq;

namespace test
{
    class Diamond
    {
        [LoadColumn(0)]
        public float Size { get; set; }
        [LoadColumn(1)]
        public float Price { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //Create MLContext
            MLContext mlContext = new MLContext();

            //Load Data Files using * wildcard
            IDataView data = mlContext.Data.LoadFromTextFile<Diamond>
                ("E:/ml/folder0/*", 
                separatorChar: ',', 
                hasHeader: true);

            // show column Size
            IEnumerable<float> sizeColumn = data.GetColumn<float>("Size").ToList();
            foreach (var v in sizeColumn)
                Console.WriteLine(v);
        }
    }
}
