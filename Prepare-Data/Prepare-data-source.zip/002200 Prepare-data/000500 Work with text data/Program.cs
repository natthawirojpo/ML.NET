﻿//  * LOY 2019 ML.NET Course

using System;
using Microsoft.ML;
using Microsoft.ML.Data;
using System.Collections.Generic;
using System.Linq;
using Microsoft.ML.Transforms;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create MLContext
            MLContext mlContext = new MLContext();

            //Load Data
            IDataView data = mlContext.Data.LoadFromTextFile<SentimentData>(
                @"E:\ml\message.tsv",
                separatorChar: '\t',
                hasHeader: true);

            // Define text transform estimator
            var estimator = mlContext.Transforms.Text.FeaturizeText(
                inputColumnName: "Message",
                outputColumnName: "Message2");

            // Fit data to estimator
            // Fitting generates a transformer that applies the operations of defined by estimator
            ITransformer textTransformer = estimator.Fit(data);

            // Transform data
            IDataView transformedData = textTransformer.Transform(data);

            IEnumerable<string> c1 = data.GetColumn<string>
                ("Message").ToList();
            Console.WriteLine("-----------show column message-------- ");
            foreach (var v in c1)
                Console.WriteLine(v);

            IEnumerable<float[]> c2 = transformedData.GetColumn<float[]>
                ("Message2").ToList();
            Console.WriteLine("-----------show featurize text-------- ");
            foreach (var v in c2)
            {
                foreach (var k in v)
                    Console.Write(k + ", ");
                Console.WriteLine("\n");
            }
        }
    }
}
