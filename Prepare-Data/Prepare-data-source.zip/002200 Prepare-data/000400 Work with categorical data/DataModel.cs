﻿//  * LOY 2019 ML.NET Course
using Microsoft.ML.Data;

using System;
using System.Collections.Generic;
using System.Text;

namespace test
{
    class AdultSmall
    {
        [LoadColumn(0)]
        public int Id { get; set; }
        [LoadColumn(1)]
        public float Age { get; set; }
        [LoadColumn(2)]
        public String WorkClass { get; set; }
        [LoadColumn(3)]
        public String Education { get; set; }
    }
}
