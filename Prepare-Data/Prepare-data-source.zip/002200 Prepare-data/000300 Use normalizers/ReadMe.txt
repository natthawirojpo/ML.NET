﻿
Use normalizers

Normalization is a data pre-processing technique used to standardize 
features that are not on the same scale which helps algorithms 
converge faster. For example, the ranges for values like age and 
income vary significantly with age generally being in the range of 
0-100 and income generally being in the range of zero to thousands. 
Visit the transforms page for a more detailed list and description 
of normalization transforms

-----------show all Price--------
7366
985
544
9140
493
3011
11413
-----------show normalized Price--------
0.64540434
0.08630509
0.047664944
0.80084115
0.043196354
0.26382196
1