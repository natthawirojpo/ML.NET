﻿//  * LOY 2019 ML.NET Course
using Microsoft.ML.Data;

using System;
using System.Collections.Generic;
using System.Text;

namespace test
{
    class Diamond
    {
        [LoadColumn(0)]
        public float Size { get; set; }
        [LoadColumn(1)]
        public float Price { get; set; }
    }
}
