﻿//  * LOY 2019 ML.NET Course

using System;
using Microsoft.ML;
using Microsoft.ML.Data;
using System.Collections.Generic;
using System.Linq;
using Microsoft.ML.Transforms;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create MLContext
            MLContext mlContext = new MLContext();

            //Load Data
            IDataView data = mlContext.Data.LoadFromTextFile<SentimentData>(
                @"E:\ml\message.tsv",
                separatorChar: '\t',
                hasHeader: true);

            // Converts all letters to lowercase by default
            var estimator = mlContext.Transforms.Text.NormalizeText(
                inputColumnName: "Message",
                outputColumnName: "Message2")

            // Splits string into individual words
            .Append(mlContext.Transforms.Text.TokenizeIntoWords(
                inputColumnName: "Message2",
                outputColumnName: "Message3"))

            // Removes stopwords like is and a.
            .Append(mlContext.Transforms.Text.RemoveDefaultStopWords(
                inputColumnName: "Message3",
                outputColumnName: "Message4"))

            // Maps the values to keys (categories) based on the input data
            .Append(mlContext.Transforms.Conversion.MapValueToKey(
                inputColumnName: "Message4",
                outputColumnName: "Message5"))

            // Transforms text into sequence of consecutive words
            .Append(mlContext.Transforms.Text.ProduceNgrams(
                inputColumnName: "Message5",
                outputColumnName: "Message6"))

            // Scale inputs by their lp-norm
            .Append(mlContext.Transforms.NormalizeLpNorm(
                inputColumnName: "Message6",
                outputColumnName: "Message7"));

            // Fit data to estimator
            // Fitting generates a transformer that applies the operations of defined by estimator
            ITransformer textTransformer = estimator.Fit(data);

            // Transform data
            IDataView transformedData = textTransformer.Transform(data);


            /// =================== console write ====================
            IEnumerable<string> c1 = data.GetColumn<string>
                ("Message").ToList();
            Console.WriteLine("-----------show original message -------- ");
            foreach (var v in c1)
                Console.WriteLine(v);

            IEnumerable<string> c2 = transformedData.GetColumn<string>
                ("Message2").ToList();
            Console.WriteLine("-----------show Message2 NormalizeText -------- ");
            foreach (var v in c2)
            {
                foreach (var k in v)
                    Console.Write(k + ", ");
                Console.WriteLine();
            }

            IEnumerable<string[]> c3 = transformedData.GetColumn<string[]>
                ("Message3").ToList();
            Console.WriteLine("-----------show Message3 TokenizeIntoWords -------- ");
            foreach (var v in c3)
            {
                foreach (var k in v)
                    Console.Write(k + ", ");
                Console.WriteLine();
            }

            IEnumerable<string[]> c4 = transformedData.GetColumn<string[]>
                ("Message4").ToList();
            Console.WriteLine("-----------show Message4 RemoveDefaultStopWords -------- ");
            foreach (var v in c4)
            {
                foreach (var k in v)
                    Console.Write(k + ", ");
                Console.WriteLine();
            }

            IEnumerable<uint[]> c5 = transformedData.GetColumn<uint[]>
                ("Message5").ToList();
            Console.WriteLine("-----------show Message5 MapValueToKey -------- ");
            foreach (var v in c5)
            {
                foreach (var k in v)
                    Console.Write(k + ", ");
                Console.WriteLine();
            }
        }
    }
}
