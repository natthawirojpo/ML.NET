﻿Working with default column names

ML.NET algorithms use default column names when none are specified. All trainers have a parameter called
featureColumnName for the inputs of the algorithm and when applicable they also have a parameter for the
expected value called labelColumnName . By default those values are Features and Label respectively.

By using the Concatenate method during pre-processing to create a new column called Features , there is no need
to specify the feature column name in the parameters of the algorithm since it already exists in the pre-processed
IDataView . The label column is CurrentPrice , but since the ColumnName attribute is used in the data model,
ML.NET renames the CurrentPrice column to Label which removes the need to provide the labelColumnName
parameter to the machine learning algorithm estimator.

If you don't want to use the default column names, pass in the names of the feature and label columns as
parameters when defining the machine learning algorithm estimator as demonstrated by the subsequent snippet:


var UserDefinedColumnSdcaEstimator = mlContext.Regression.Trainers.Sdca(labelColumnName: "MyLabelColumnName",
featureColumnName: "MyFeatureColumnName");



