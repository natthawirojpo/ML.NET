﻿//  * LOY 2019 ML.NET Course

using System;
using Microsoft.ML;
using Microsoft.ML.Data;
using System.Collections.Generic;
using System.Linq;
using Microsoft.ML.Transforms;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create MLContext
            MLContext mlContext = new MLContext();

            //Load Data
            IDataView data = mlContext.Data.LoadFromTextFile<Diamond>(
                @"E:\ml\diamond1.csv",
                separatorChar: ',',
                hasHeader: true);

            Preview(data);

            // -------------------------------------------------------------------
            // Create pipeline
            var pipeline = mlContext.Transforms.CopyColumns(
                inputColumnName: "Size",
                outputColumnName: "Karat")

                //  copy column
                .Append(mlContext.Transforms.CopyColumns(
                inputColumnName: "Price",
                outputColumnName: "Cost"))
                
                .Append(mlContext.Transforms.DropColumns(
                    "Size", "Price"));

            // Create data prep transformer
            ITransformer pepData = pipeline.Fit(data);

            // Apply tranforms to training data
            IDataView transData = pepData.Transform(data);

            Preview(transData);

            // change feature and lable from default column names
            var model = mlContext.Regression.Trainers.Sdca(
                labelColumnName: "Cost",
                featureColumnName: "Karat"
                );

        }

        public static void Preview(IDataView data)
        {
            var myPreview = data.Preview();
            Console.WriteLine("\n-----------show original data-------- ");

            for (int k = 0; k < myPreview.Schema.Count(); k++)
                Console.Write($"{myPreview.Schema[k]} | ");
            Console.WriteLine("\n----------------------------------- ");

            for (int j = 0; j < myPreview.RowView.Count(); j++)
            {
                for (int i = 0; i < myPreview.ColumnView.Count(); i++)
                {
                    var v = myPreview.ColumnView[i].Values.GetValue(j);
                    Console.Write($"{v}\t");
                }
                Console.WriteLine();
            }
        }
    }
}
