﻿Drop column

TransformExtensionsCatalog.DropColumns(TransformsCatalog, String[]) Method

Create a ColumnSelectingEstimator, which drops a given list of columns from 
an IDataView. Any column not specified will be maintained in the output.


