﻿Working with expected column types

The machine learning algorithms in ML.NET expect a float vector of known size as input. Apply the VectorType
attribute to your data model when all of the data is already in numerical format and is intended to be processed
together (i.e. image pixels).

If data is not all numerical and you want to apply different data transformations on each of the columns
individually, use the Concatenate method after all of the columns have been processed to combine all of the
individual columns into a single feature vector that is output to a new column.

The this example combines the workclass and education columns into a single feature vector that is
output to a new column called Features . Because there is a difference in scales, NormalizeMinMax is applied to the
Features column to normalize the data.