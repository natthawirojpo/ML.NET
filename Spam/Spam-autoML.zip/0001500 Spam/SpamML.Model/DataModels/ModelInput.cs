//*****************************************************************************************
//*                                                                                       *
//* This is an auto-generated file by Microsoft ML.NET CLI (Command-Line Interface) tool. *
//*                                                                                       *
//*****************************************************************************************

using Microsoft.ML.Data;

namespace SpamML.Model.DataModels
{
    public class ModelInput
    {
        [ColumnName("class"), LoadColumn(0)]
        public bool Class { get; set; }


        [ColumnName("message"), LoadColumn(1)]
        public string Message { get; set; }


    }
}
