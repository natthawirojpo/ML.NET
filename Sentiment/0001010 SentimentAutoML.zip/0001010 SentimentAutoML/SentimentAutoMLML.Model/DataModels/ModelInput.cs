//*****************************************************************************************
//*                                                                                       *
//* This is an auto-generated file by Microsoft ML.NET CLI (Command-Line Interface) tool. *
//*                                                                                       *
//*****************************************************************************************

using Microsoft.ML.Data;

namespace SentimentAutoMLML.Model.DataModels
{
    public class ModelInput
    {
        [ColumnName("Message"), LoadColumn(0)]
        public string Message { get; set; }


        [ColumnName("Label"), LoadColumn(1)]
        public bool Label { get; set; }


    }
}
