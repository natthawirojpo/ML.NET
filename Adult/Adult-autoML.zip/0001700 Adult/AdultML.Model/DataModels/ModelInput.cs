//*****************************************************************************************
//*                                                                                       *
//* This is an auto-generated file by Microsoft ML.NET CLI (Command-Line Interface) tool. *
//*                                                                                       *
//*****************************************************************************************

using Microsoft.ML.Data;

namespace AdultML.Model.DataModels
{
    public class ModelInput
    {
        [ColumnName("id"), LoadColumn(0)]
        public float Id { get; set; }


        [ColumnName("age"), LoadColumn(1)]
        public float Age { get; set; }


        [ColumnName("workclass"), LoadColumn(2)]
        public string Workclass { get; set; }


        [ColumnName("fnlwgt"), LoadColumn(3)]
        public float Fnlwgt { get; set; }


        [ColumnName("education"), LoadColumn(4)]
        public string Education { get; set; }


        [ColumnName("education_num"), LoadColumn(5)]
        public float Education_num { get; set; }


        [ColumnName("marital_status"), LoadColumn(6)]
        public string Marital_status { get; set; }


        [ColumnName("occupation"), LoadColumn(7)]
        public string Occupation { get; set; }


        [ColumnName("relationship"), LoadColumn(8)]
        public string Relationship { get; set; }


        [ColumnName("ethnicity"), LoadColumn(9)]
        public string Ethnicity { get; set; }


        [ColumnName("sex"), LoadColumn(10)]
        public string Sex { get; set; }


        [ColumnName("capital_gain"), LoadColumn(11)]
        public float Capital_gain { get; set; }


        [ColumnName("capital_loss"), LoadColumn(12)]
        public float Capital_loss { get; set; }


        [ColumnName("hours_per_week"), LoadColumn(13)]
        public float Hours_per_week { get; set; }


        [ColumnName("native_country"), LoadColumn(14)]
        public string Native_country { get; set; }


        [ColumnName("label"), LoadColumn(15)]
        public bool Label { get; set; }


    }
}
