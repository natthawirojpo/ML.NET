﻿using System;
using System.Collections.Generic;

namespace AdultML.Models
{
    public partial class Adult
    {
        public short Id { get; set; }
        public byte Age { get; set; }
        public string Workclass { get; set; }
        public int Fnlwgt { get; set; }
        public string Education { get; set; }
        public byte EducationNum { get; set; }
        public string MaritalStatus { get; set; }
        public string Occupation { get; set; }
        public string Relationship { get; set; }
        public string Ethnicity { get; set; }
        public string Sex { get; set; }
        public int CapitalGain { get; set; }
        public short CapitalLoss { get; set; }
        public byte HoursPerWeek { get; set; }
        public string NativeCountry { get; set; }
        public bool Label { get; set; }
    }
}
