//*****************************************************************************************
//*                                                                                       *
//* This is an auto-generated file by Microsoft ML.NET CLI (Command-Line Interface) tool. *
//*                                                                                       *
//*****************************************************************************************

using Microsoft.ML.Data;

namespace IrisML.Model.DataModels
{
    public class ModelInput
    {
        [ColumnName("slen"), LoadColumn(0)]
        public float Slen { get; set; }


        [ColumnName("swidth"), LoadColumn(1)]
        public float Swidth { get; set; }


        [ColumnName("plen"), LoadColumn(2)]
        public float Plen { get; set; }


        [ColumnName("pwidth"), LoadColumn(3)]
        public float Pwidth { get; set; }


        [ColumnName("class"), LoadColumn(4)]
        public string Class { get; set; }


    }
}
