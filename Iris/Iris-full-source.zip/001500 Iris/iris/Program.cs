﻿//  * LOY 2019 ML.NET Course

using System;
using System.IO;
using Microsoft.ML;

namespace iris
{
    class Program
    {
        static readonly string _dataPath = Path.Combine
            (Environment.CurrentDirectory, "Data", "iris-data-train.csv");

        static readonly string _modelPath = Path.Combine
            (Environment.CurrentDirectory, "Data", "IrisClusteringModel.zip");

        static void Main(string[] args)
        {
            var mlContext = new MLContext(seed: 0);

            IDataView dataView = mlContext.Data.LoadFromTextFile<IrisData>
                (_dataPath, hasHeader: false, separatorChar: ',');

            string featuresColumnName = "Features";

            var pipeline = mlContext.Transforms
                .Concatenate(featuresColumnName, "SepalLength", "SepalWidth", "PetalLength", "PetalWidth")
                .Append(mlContext.Clustering.Trainers.KMeans(featuresColumnName, numberOfClusters: 3));

            var model = pipeline.Fit(dataView);

            using (var fileStream = new FileStream(_modelPath, FileMode.Create, FileAccess.Write, FileShare.Write))
            {
                mlContext.Model.Save(model, dataView.Schema, fileStream);
            }

            var predictor = mlContext.Model.CreatePredictionEngine<IrisData, ClusterPrediction>(model);

            var prediction = predictor.Predict(TestIrisData.Setosa);
            Console.WriteLine($"Cluster: {prediction.PredictedClusterId}");
            Console.WriteLine($"Distances: {string.Join(" ", prediction.Distances)}");
        }
    }
}

/* output result
 * 
Cluster: 3
Distances: 0.32727432 16.767582 0.09206009

 */

    // distance smallser is better because it close to that cluster
    // in this case Cluster = 3 because 0.09 is the nearest cluster